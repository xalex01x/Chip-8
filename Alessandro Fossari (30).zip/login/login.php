<?php
require_once '../other/db.php';
session_start();

function verificaLogin($u, $p) {
    try {
        $db = new DB();
        $pdo = $db->retPDO();
        $sql = "SELECT username, password FROM player WHERE username = :username;";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username', $u);
        $stmt->execute();
        $row = $stmt->fetch();
        if ($row && $row["username"] === $u) {  // cerchiamo se l'username esiste
            if (password_verify($p, $row["password"])) {    // verifica della password usando password_verify
                $end = 3;   // esito corretto
            } else {
                $end = 1;   // password errata
            }
        } else {
            $end = 2;   // utente non registrato
        }
        $db->endPDO();
        return $end;
    } catch (PDOException $e) { // gestione dell'errore
        $_SESSION["errorLog"] = $e->getMessage();
        $_SESSION["error"] = "Il server non è riuscito a verificare il login. Riprova più tardi.";
        $db->endPDO();
        header("Location: ../other/errorPage.php");
        return 0; // esito erroneo
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username']) && isset($_POST['password'])) {   // leggiamo i dati di login dalla richiesta POST
    $username = $_POST['username'];
    $password = $_POST['password'];
    $validi = '/^[A-Za-z0-9]+$/';
    
    if (preg_match($validi, $username) && preg_match($validi, $password)) { // validazione di entrambi i campi
        $res = verificaLogin($username, $password); // chiamiamo la funzione di verifica
        switch ($res) { // gestione del risultato della funzione
            case 1: // password errata
                $_SESSION["errorLog"] = '';
                $_SESSION["error"] = "Password errata.";
                header("Location: ../other/errorPage.php");
                break;
            case 2: // utente non registrato
                $_SESSION["errorLog"] = '';
                $_SESSION["error"] = "Non ti sei ancora registrato.";
                header("Location: ../other/errorPage.php");
                break;
            case 3: // accesso alla homepage
                $_SESSION["user"] = $username;
                header('Location: ../homepage/homeIndex.php');
                break;
            default:    // errori già gestiti dalla funzione
                break;
        }
    } else {    // gestione errori di validazione
        $_SESSION["errorLog"] = '';
        $_SESSION["error"] = "Il formato dell'username o della password non è valido";
        header("Location: ../other/errorPage.php");
    }
}
?>
