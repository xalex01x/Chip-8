<?php
require_once "../other/db.php";
session_start();

function registrati($u, $p) {
    try {
        $db = new DB();
        $pdo = $db->retPDO();
        $sql = "SELECT username FROM player WHERE username = :username;";   // vediamo se nel database l'username esiste già
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username', $u);
        $stmt->execute();
        $row = $stmt->fetch();
        if ($row) {
            $end = 2; // esiste già qualcuno con questo nome
        } else {
            $sql = "INSERT INTO player (username, password) VALUES (:username, :password);";
            $stmt = $pdo->prepare($sql);
            $hashedPassword = password_hash($p, PASSWORD_BCRYPT);
            $stmt->bindParam(':username', $u);
            $stmt->bindParam(':password', $hashedPassword);
            $stmt->execute();
            $end = 1; // registrazione avvenuta con successo
        }
        $db->endPDO();
        return $end;
    } catch (PDOException $e) {
        $_SESSION["errorLog"] = $e->getMessage();
        $_SESSION["error"] = "Il server non è riuscito a salvare i dati relativi alla registrazione.";
        $db->endPDO();
        header("Location: ../other/errorPage.php");
        return 0; // errore nella registrazione
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {     // se si tratta di una richiesta POST verificane il contenuto
    $validi = '/^[A-Za-z0-9]{8,}$/';
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    
    if (preg_match($validi, $username) && preg_match($validi, $password) && preg_match($validi, $confirmPassword) && $password === $confirmPassword) {  // se lo username e la password hanno un formato valido e la password è confermata correttamente allora prosegui
        $res = registrati($username, $password);    // funzione di registrazione
        switch ($res) {
            case 1:     // una volta registrato è possibile accedere al login
                header('Location: ../index.html');
                break;
            case 2:     // esiste già lo stesso username
                $_SESSION["errorLog"] = '';
                $_SESSION["error"] = "Qualcuno utilizza già questo username.";
                header("Location: ../other/errorPage.php");
                break;
            default:    // eventuali altri esiti (quello di errore)
                break;
        }
    } else {    // i dati ricevuti non avevano formato valido
        $_SESSION["errorLog"] = '';
        $_SESSION["error"] = "I dati inseriti hanno un formato non valido.";
        header("Location: ../other/errorPage.php");
    }
}
?>