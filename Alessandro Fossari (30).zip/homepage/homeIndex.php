<?php
require "../other/db.php";
session_start();
if (!isset($_SESSION["user"])) {    // se l'utente non è loggato torna al login
    header("Location: ../index.html");
    exit;
}
function formatTime($milliseconds) {    // funzione per visualizzare il tempo impiegato a svolgere una corsa
    $minutes = floor($milliseconds / 60000);
    $seconds = floor(($milliseconds % 60000) / 1000);
    $ms = $milliseconds % 1000;
    $formattedTime = sprintf('%02d:%02d:%03d', $minutes, $seconds, $ms);
    return $formattedTime;
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>All-Day Drifting</title>
    <link rel="stylesheet" href="homeStyle.css">
</head>
<body>
    <header>
        <h1>All-Day Drifting</h1>
    </header>
    <main>
        <section id="userProfile"> <!-- selezione della pista e dello sfidante -->
            <h2>Profilo</h2>
            <div class="userData">
                <p><strong>User: </strong><?php echo $_SESSION["user"] ?></p>
                <form action="trackUpdate.php" method="GET" id="trackForm">
                    <div>
                        <label for="currentTrack">Scegli una pista:</label>
                        <input type="text" id="currentTrack" name="currentTrack" pattern="[0-9]{1,2}" title="Solo caratteri numerici." required>
                    </div>
                    <div>
                        <label for="gauntlet">Inserisci chi sfidare:</label>
                        <input type="text" id="gauntlet" name="gauntlet" pattern="[A-Za-z0-9]{8,45}" title="Solo caratteri alfanumerici. Lunghezza minima 8 caratteri.">
                    </div>
                    <button type="submit" id="trackFormButton">Nuova Gara</button>
                </form>
            </div>
            <div id="profileSpacing"></div>
            <p><a class="guideLink" href="../other/guideIndex.html">Guida al gioco ed ai comandi</a></p>
            <p><a class ="guideLink" href = "closeSession.php">Logout</a></p>
        </section>
        <section id="availTracks"> <!-- barra di ricerca delle piste, miglior giocatore su ciascuna pista e miglior tempo -->
            <h2>Piste Disponibili</h2>
            <div class="trackList">
                <?php
                $db = new DB();
                $pdo = $db->retPDO();   // visualizziamo tutte le piste e per ognuna il player migliore con il suo tempo
                $sql = "SELECT T.trackID, R.player, R.time
                FROM track T LEFT OUTER JOIN
                (SELECT g1.trackID, g1.player, g1.time
                FROM ghostData g1
                JOIN (SELECT trackID, MIN(time) AS min_time
                FROM ghostData
                GROUP BY trackID) g2 ON g1.trackID = g2.trackID AND g1.time = g2.min_time
                GROUP BY g1.trackID, g1.time) R ON R.trackID = T.trackID;";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();
                while ($row = $stmt->fetch()) {
                    if ($row["player"])
                        $p = $row["player"];
                    else
                        $p = "------";  // nel caso nessuno abbia mai corso sulla pista usa del testo placeholder
                    if ($row["time"])
                        $t = formatTime($row["time"]);
                    else
                        $t = "--:--:---";   // placeholder anche per il tempo migliore
                    echo "<div class = \"trackScroll\">
                        <img alt = \"Track " . $row["trackID"] . " preview.\" src=\"../game/assets/track" . $row["trackID"] . ".png\">
                        <div>
                            <p>Track " . $row["trackID"] . "</p>
                            <p> Miglior Tempo:</p><p>" . $p . " " . $t . "</p>
                        </div>
                        </div>"; // metti a video la presentazione della pista
                }
                ?>
            </div>
        </section>
        <section id="guida">    <!-- graduatoria dei dieci migliori giocatori -->
            <h2>Graduatorie</h2>
            <div id="leadShowContainer">
                <form method="GET" id="leadForm">
                    <div>
                        <label for="leadTrack">Pista:</label>
                        <input type="text" id="leadTrack" name="leadTrack" pattern="[0-9]{1,2}" title="Solo caratteri numerici." required>
                    </div>
                    <button type="submit" id="leadFormButton">Classifica</button>
                </form>
                <div id="leadShow">
                    <?php
                    include 'showLead.php';
                    if (isset($_GET["leadTrack"]))  // quando si seleziona una pista della quale vedere la graduatoria viene chiamata la printLead()
                        printLead();
                    ?>
                </div>
            </div>
        </section>
    </main>
</body>
</html>