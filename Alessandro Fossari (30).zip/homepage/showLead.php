<?php
function printLead() {
    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['leadTrack'])) {     // se la richiesta è di tipo GET ed il campo relativo alla graduatoria è settato prosegui
        $track = $_GET['leadTrack'];
        $validi = '/^[0-9]+$/';
        if (!preg_match($validi, $track)) {     // validazione dell'identificatore della pista ed eventuale gestione errore
            $_SESSION["error"] = "L'ID della pista è in un formato invalido.";
            header("Location: ../other/errorPage.php");
            exit;
        }
        try {
            $db = new DB();
            $pdo = $db->retPDO();
            $sql = "SELECT player, time FROM ghostData WHERE trackID = :trackID ORDER BY time;";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':trackID', $track);
            $stmt->execute();
            $i = 10;
            $pos = 1;
            $str = "";
            while ($i && $row = $stmt->fetch()) {   // otteniamo la graduatoria e mettiamola a video
                $str .= "<div class=\"leadRow pos" . $pos . "\"><div class=\"leadField\">" . $row["player"] . "</div><div class=\"leadField\">" . formatTime($row["time"]) . "</div></div>";
                $i--;
                $pos++;
            }
            $db->endPDO();
            echo $str;
            exit;
        } catch (PDOException $e) { // gestione errori
            $_SESSION["errorLog"] = $e->getMessage();
            $_SESSION["error"] = "Il server non è riuscito ad ottenere i dati relativi alla pista. Riprova più tardi.";
            $db->endPDO();
            header("Location: ../other/errorPage.php");
            exit;
        }
    }
}
?>