<?php
session_start();
if (isset($_SESSION["user"])) session_destroy();    // distruzione della sessione
header("Location: ../index.html");  // ritorno alla pagina di login
?>