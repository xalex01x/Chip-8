<?php
require("../other/db.php");
session_start();
if (!isset($_SESSION["user"])) {    // se l'utente non si è loggato allora gestiscilo
    header("Location: ../index.html");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['currentTrack'])) {  // richiesta GET e verifica del campo relativo alla pista selezionata
    $track = $_GET['currentTrack'];
    $gauntlet = $_GET['gauntlet'] ?? '';    // se non si sfida nessuno inizializza il campo come vuoto
    $validiTrack = '/^[0-9]+$/';
    $validiGauntlet = '/^[A-Za-z0-9]+$/';
    if (!preg_match($validiTrack, $track)) {    // validazione dell'identificatore di pista ed eventuale gestione dell'errore
        $_SESSION["errorLog"] = '';
        $_SESSION["error"] = "L'ID della pista è in un formato invalido.";
        header("Location: ../other/errorPage.php");
        exit;
    }
    $db = new DB();
    $pdo = $db->retPDO();
    try {
        $sql = "SELECT * FROM track WHERE trackID = :trackID;";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':trackID', $track);
        $stmt->execute();
        $row = $stmt->fetch();  // anche se l'id è sintatticamente corretto, non è detto che la pista esista: va controllato
        if ($row) {
            $_SESSION["currentTrack"] = $track;
        } else {
            $_SESSION["errorLog"] = '';     // gestione errore di inesistenza della pista
            $_SESSION["error"] = "La pista selezionata non esiste.";
            $db->endPDO();
            header("Location: ../other/errorPage.php");
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION["errorLog"] = $e->getMessage();   // gestione errore pdo
        $_SESSION["error"] = "Il server non è riuscito ad ottenere i dati relativi alla pista. Riprova più tardi.";
        $db->endPDO();
        header("Location: ../other/errorPage.php");
        exit;
    }
    if ($gauntlet == '') {  // se non si vuole sfidare nessuno allora siamo pronti a giocare
        $_SESSION['gauntlet'] = '';
        $db->endPDO();
        header("Location: ../game/gameIndex.php");
        exit;
    } else {
        if (preg_match($validiGauntlet, $gauntlet)) {   // se si vuole sfidare qualcuno controlla che il nome del player inserito sia valido
            try {
                $sql = "SELECT player, route FROM ghostData WHERE trackID = :trackID AND player = :player;";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':trackID', $_SESSION['currentTrack']);
                $stmt->bindParam(':player', $gauntlet);
                $stmt->execute();
                $row = $stmt->fetch();
                if ($row && $row["route"]) {    // cerchiamo se il player abbia corso almeno una volta sulla pista richiesta: se si leggiamo i dati relativi alla partita
                    $_SESSION["gauntletData"] = $row["route"];
                    $_SESSION["gauntlet"] = $gauntlet;
                } else {
                    $_SESSION["errorLog"] = '';     // se lo sfidato non ha mai corso gestiamo anche questo
                    $_SESSION["error"] = "Il player che hai chiesto di sfidare non esiste o non ha mai corso su questa pista.";
                    $db->endPDO();
                    header("Location: ../other/errorPage.php");
                    exit;
                }
            } catch (PDOException $e) { // gestione errore del pdo per il secondo gruppo di query
                $_SESSION["errorLog"] = $e->getMessage();
                $_SESSION["error"] = "Il server non è riuscito ad ottenere i dati relativi al player sfidato. Riprova più tardi.";
                $db->endPDO();
                header("Location: ../other/errorPage.php");
                exit;
            }
        } else {
            $_SESSION["errorLog"] = '';     // gestione errore di validazione
            $_SESSION["error"] = "Il nome del giocatore sfidato ha un formato invalido.";
            $db->endPDO();
            header("Location: ../other/errorPage.php");
            exit;
        }
    }
    $db->endPDO();  // una volta aver ottenuto i dati di uno sfidato possiamo giocare
    header("Location: ../game/gameIndex.php");
    exit;
}
?>