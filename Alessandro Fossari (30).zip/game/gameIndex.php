<?php
session_start();
if (!isset($_SESSION["user"]) || !isset($_SESSION["currentTrack"])) {    // consenti l'accesso solo a chi si è già loggato
    header("Location: ../index.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>All-Day Drifting</title>
    <link rel="stylesheet" href="gameStyle.css">
</head>
<body>
    <main>
        <div id="topBody">
            <div id="onScreenText" class="sideSection"> <!-- nella prima sezione sono contenute alcune informazioni sul player, sullo sfidante, sul giro ed il bottone di ritorno alla hompage -->
                <div id="textDiv">
                    <p class="titolo information"> <?php echo $_SESSION["user"] ?> </p>
                    <p class="titolo information"> <?php if ($_SESSION["gauntlet"])
                        echo "Sfidando: " . $_SESSION["gauntlet"];
                    else
                        ''; ?></p>
                    <p class="titolo information"> <?php echo "Track " . $_SESSION["currentTrack"] ?>
                    <p id="lapElement" class="titolo information">Giro 1</p>
                    <p id="lapDurationElement" class="information"></p>
                </div>
                <div id="buttonDiv">
                    <button onclick="returnFun()">Homepage</button>
                </div>
            </div>
            <div id="container">    <!-- nella seconda sezione è contenuto il gioco vero e proprio-->
                <div id="overlay">
                    <p id="charScreen"></p>
                </div>
                <div id="canvasContainer">
                <canvas id="gameCanvas" height="600" width="1000"></canvas>
                <canvas id="carCanvas" height="600" width="1000"></canvas>
                </div>
            </div>
            <div class="sideSection"> <!-- nella terza sezione ci sono le barre della velocità e del boost-->
                <div id="speedSection">
                    <div>
                        <div id="speedDivContainer">
                            <div id="speedDiv"></div>
                        </div>
                        <p>Velocità</p>
                    </div>
                    <div>
                        <div id="boostDivContainer">
                            <div id="boostDiv"></div>
                        </div>
                        <p>Boost</p>
                    </div>
                </div>
            </div>
        </div>
        <div id="lowBody">
            <p id="gameLog"></p>
        </div>
        <script src="gameScript.js"></script>
    </main>
</body>
</html>