const canvas = document.getElementById('gameCanvas');   // riferimenti ad elementi html vari, quali due canvas e diversi div che mettono dei dati a video
const carCanvas = document.getElementById('carCanvas');
var lapField = document.getElementById("lapElement");
var lapDuration = document.getElementById("lapDurationElement");
var speedBar = document.getElementById("speedDiv");
var boostBar = document.getElementById("boostDiv");
var log = document.getElementById("gameLog");
const ctx = canvas.getContext('2d', { willReadFrequently: true });    // inizializzazione dei canvas
const carCtx = carCanvas.getContext('2d');
var carImage = new Image();     // inizializzazione degli assets di gioco
carImage.src = './assets/car_texture.png';
var trackImage = new Image();
trackImage.crossOrigin = 'Anonymous';

const topSpeed = 12;    // velocità in marcia avanti
const reverseTopSpeed = 5; // velocità in retromarcia, deve essere positiva 
const boostMultiplier = 0.07; // incremento della velocità al boost
const width = 60;   // larghezza veicolo
const height = 120; // altezza veicolo
const barrierCheckR = canvas.height / 2;    // il raggio attorno alla macchina per cercare barriere visibili
const sampleTime = 250;    // tempo di disegno ghost / campionamento giocatore
var square = [0, 0, 0, 0];  // quadrato di controllo delle barriere visibili
var carEngine = 0;  // serve ad animare il motore della macchina
var collisionID = 'n';  // id della barriera attualmente in contatto alla macchina
var nextCheck = 'c1';   // prossimo checkpoint da attraversare
var lapCount = 1;   // numero del giro corrente
var timestamp = []; // vettore che memorizza il tempo di attraversamento del traguardo ad ogni giro
var spawnX = 0;     // coordinate di spawn dell'auto
var spawnY = 0;
var spawnAngle = 0;
var intervals = []; // vettore che memorizza gli intervalli delle funzioni ricorsive
var gauntlet = 0;   // se uguale a "1" indica che si sta sfidando qualcuno
var grass = 0;  // se uguale ad "1" indica che la macchina si trova nell'erba

const sideX1 = width / 2.3; // costanti per l'hitbox
const sideY1 = height / 2.3;
const sideX2 = -sideY1;
const sideY2 = sideX1;

var ghostIndex = 0; //variabili per il ghost

var car = {
    x: spawnX,  // coordinate dell'auto
    y: spawnY,
    inBoost: 0,    // verifica che il player sia in un boost
    speed: 0,   // velocità
    angle: spawnAngle,   // orientamento auto
    sinA: Math.sin(spawnAngle),   // seno e coseno dell'angolo della macchina vengono comunque calcolati al variare dell'angolo. Tanto vale memorizzarli qui
    cosA: Math.cos(spawnAngle),
    fl: [0, 0],     // coordinate dei quattro punti di hitbox dell'auto: front-left
    fr: [0, 0],     // front-right
    bl: [0, 0],     //back-left
    br: [0, 0]      //back-right
};

var track = {   // costanti relative alla pista
    width: 2480,
    height: 3508,
};

class Barrier {     // classe barriera. Si tratta di un segmento espresso attraverso le quattro coordinate dei punti tra i quali è sotteso, un id ed un booleano
    constructor(id, x1, y1, x2, y2) {
        this.id = id;   // identifica la barriera. Un id che inizia per "b" indica una barriera vera e propria mentre uno che inizia per "c" indica un checkpoint ("c0" è il traguardo)
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.visible = false;   // booleano che esprime se la barriera è visibile al giocatore o meno: per risparmiare controlliamo le collisioni solo sulle barriere visibili al giocatore
    }
}

class ghostData {   // classe per la ricostruzione del percorso del ghost
    constructor(x, y, a) { // coordinate ed angolazione dello sfidato nella ricostruzione del suo percorso
        this.x = x;
        this.y = y;
        this.a = a;
    }
}

var keys = {    // vettore per riferirsi ai tasti battuti da tastiera
    ArrowUp: false,
    ArrowDown: false,
    ArrowLeft: false,
    ArrowRight: false,
    Space: false
};

var center = {      // constanti per tenere traccia di particolari punti di riferimento del canvas
    screenX: canvas.width / 2,
    screenY: canvas.height / 2,
    carX: canvas.width / 2,
    carY: canvas.height / 2 + height
};

var gameBarriers = [];  // array per le barriere di gioco
var playerPos = ["placeholder"];    // vettore per memorizzare il percorso del giocatore corrente. Il primo membro è occupato da un campo placeholder perchè vi verrà sostituito il tempo di corsa.
var ghostPos = [];  // vettore nel quale inserire il percorso del ghost

function driftCorrectingInterval(cb, delay) { // funzione per la gestione dei timer di gioco
    var begin = performance.now(),          // utilizzare Date.now(), setInterval() e clearInterval() rallenta i giocatori su browser Firefox
        result = {                          // anzichè utilizzare loro ci si avvale di setTimeout() e clearTimeout(), la prima delle quali viene chiamata leggermente prima o dopo in base alle esigenze
            _id: setTimeout(inner, delay),  // il codice originale proviene da https://stackoverflow.com/questions/50115731/the-differences-of-setinterval-between-chrome-and-other-browsers-why/50115944#50115944
                                            // poi leggermente modificato per implementare la clear
            clear: function () {
                clearTimeout(this._id);
            }
        },
        passed = true;
    return result;  // ritorna l'interval come farebbe una setInterval()

    function inner() {
        if (!passed) return;    // "passed" serve a fare in modo che valori estremi del drift temporale non facciano richiamare la funzione argomento più volte nello stesso intervallo di delay. Viene infatti messo a false nel body di "inner" e questo "if" evita di proseguire se passed == false
        passed = false;
        var now = performance.now();
        var d = (now - begin) - delay;  // calcolo del drift temporale
        begin += delay;
        result._id = setTimeout(inner, delay - d);  // la funzione inner la quale viene usata per richiamare la funzione argomento periodicamente viene chiamata leggermente in ritardo / anticipo rispetto al delay richiesto
        cb();   // cb() è la funzione da richiamare, passata come argomento a driftCorrectingInterval()
        passed = true;
    }
}

function storePos() {   // memorizzazione della posizione corrente del player. Una volta terminato il giro i dati raccolti verranno salvati se il giro è ottimo
    if (Date.now() - timestamp[0] >= 120000) intervals[3].clear(); // se si impiega più di due minuti a finire un percorso allora non salvare ulteriori posizioni per evitare che il percorso occupi troppa memoria
    const str = Math.floor(car.x) + "," + Math.floor(car.y) + "," + Math.floor(car.angle*1000)/1000;
    playerPos.push(str);
}

async function sendPos() {    // salvataggio del percorso seguito dal player ed invio al server
    playerPos[0] = timestamp[0];    // playerPos[0] (prima "placeholder") viene settato al tempo totale impiegato
    try {
        const jsonPos = JSON.stringify(playerPos);  // inviamo al server attraverso richiesta POST i dati, specificando che il contenuto è del codice json
        const response = await fetch('saveData.php', {  // la sintassi necessaria ad effettuare la richiesta POST è stata presa da: https://stackoverflow.com/questions/70069446/set-content-type-to-application-json-using-fetch-api-javascript
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: jsonPos
        });
        if (response.ok) log.innerText += "La partita è stata salvata.\r";  // la risposta all'invio dei dati viene messa a video per il giocatore a fine partita
        else log.innerText += "Non è stato possibile inviare il percorso al server. \r";
    } catch (error) {
        log.innerText += "Errore nell'invio del percorso al server: " + error + "\r";
    }
}

async function getData() {    // chiamata prima di una partita per ottenere i dati necessari, quali pista selezionata, player sfidato e relativo percorso
    try {
        const response = await fetch('sessionData.php');    // attendiamo risposta dal server
        const data = await response.json();     // ci aspettiamo l'identificatore della pista ed il percorso dello sfidato
        const trackID = data.trackID;
        const jsonData = data.jsonData;
        return [trackID, jsonData];
    } catch (error) {
        log.innerText += "Errore nell'ottenere i dati: (" + error + ")\r";  // messa a video di eventuali errori per il player
    }
}

async function dataInit() {     // funzione per l'inizializzazione dei dati di giochi, quali il percorso del ghost o le informazioni relative alla pista (texture e barriere)
    var trackID, jsonData;
    try {
        [trackID, jsonData] = await getData();  // chiamiamo getData()
    }
    catch (error) {
        log.innerText += error + "\r";  // messa a video di eventuali errori per l'utente
    }
    try {
        if (jsonData) {   // non bisogna creare il vettore se non esistono dati json
            gauntlet = 1;   // booleano che indica se ci troviamo in una sfida o meno: in questo caso "1" indica che lo siamo
            const routeData = JSON.parse(jsonData);     // scomponiamo i dati json e ricostruiamo il percorso del ghost
            for (let i = 1; i < routeData.length; i++) {
                const str = routeData[i].split(',');
                ghostPos.push(new ghostData(str[0], str[1], str[2]));   // inseriamo tutte le informazioni in un vettore per la gestione del ghost
            }
        }
    } catch (error) {   // messa a video di eventuali errori
        log.innerText += "Non è stato possibile ottenere i dati relativi al percorso del ghost: (" + error + ")\r";
    }
    try {
        var path = 'assets/track' + trackID + '_data.json';     // proviamo ad accedere ai dati relativi alla pista
        trackImage.src = './assets/track' + trackID + '.png';   // lo sfondo di gioco viene impostato alla pista richiesta
        const response = await fetch(path);     // lettura del file relativo alla pista richiesta
        const data = await response.json();     // dati nel file letto sopra
        car.x = data.spawnX;    // inizializzazione della posizione della macchina
        car.y = data.spawnY;
        car.angle = data.spawnAngle;
        data.barriers.forEach(b => {    // inizializzazione delle barriere di gioco
            gameBarriers.push(new Barrier(b.id, b.x1, b.y1, b.x2, b.y2));
        });
    } catch (error) {   // messa a video errori per il player
        log.innerText += "Non è stato possibile caricare barriere e posizione della macchina: (" + error + ")\r";
    }
}

function drawGhost() {  // il percorso del ghost non è che una serie di campioni relativi alla sua posizione. Questa funzione si occupa di interpolarli linearmente
    if (ghostIndex == ghostPos.length - 2) {    // i punti vengono presi a due a due e l'ultimo punto non ha quindi un successivo. Terminiamo quindi un punto prima
        gauntlet = 0;   // la sfida è terminata
        return;
    }
    const startTime = timestamp[0] + ghostIndex * sampleTime;   // se timestamp[0] contiene il timestamp di partenza, allora sommando il tempo di campionamento * l'indice con cui stiamo scorrendo il vettore del ghost otteniamo l'istante nel quale il ghost si trovava nel punto dal quale sta partendo il tratto di interpolazione
    const elapsedTime = Date.now() - startTime;     // il tempo trascorso dall'ultimo istante di campionamento del ghost. Si tratta di un valore in [0, sampleTime)
    const t = elapsedTime / sampleTime;     // il valore t indica la parcentuale di tratto che il ghost ha percorso tra due punti

    const p0 = ghostPos[ghostIndex];    // i due punti tra i quali è sotteso il tratto di interpolazione
    const p1 = ghostPos[ghostIndex + 1];
    if (elapsedTime >= sampleTime) ghostIndex = ghostIndex + 1; // interpoliamo la prossima coppia di punti se la precedente è finita

    const currentX = Number(p0.x) + (Number(p1.x) - Number(p0.x)) * t;  // interpolazione lineare di coordinate ed angolo
    const currentY = Number(p0.y) + (Number(p1.y) - Number(p0.y)) * t;
    const currentA = Number(p0.a) + (Number(p1.a) - Number(p0.a)) * t;
    ctx.translate(-currentX, -currentY);    // disegno del ghost sul canvas sfruttando le coordinate appena calcolate
    ctx.rotate(currentA);
    ctx.translate(currentX, currentY);
    ctx.translate(0, 0);
    ctx.drawImage(carImage, -currentX - width / 2, -currentY - height / 2, width, height);
}

function drawBarriers() {   // funzione prettamente di debug: disegna su canvas le barriere della mappa
    for (let i = 0; i < gameBarriers.length; i++) {
        ctx.beginPath();
        ctx.moveTo(gameBarriers[i].x1, gameBarriers[i].y1);
        ctx.lineTo(gameBarriers[i].x2, gameBarriers[i].y2);
        ctx.strokeStyle = gameBarriers[i].visible ? (gameBarriers[i].id[0] == 'c' ? 'blue' : 'red') : 'green';
        ctx.lineWidth = 10;
        ctx.stroke();
    }
}

function drawCar() {    // disegna la macchina del giocatore sul canvas
    carCtx.save();
    carCtx.drawImage(carImage, center.screenX - width / 2, center.screenY + height / 2 + carEngine, width, height);  // carEngine permette di animarla come se fosse in moto
    carCtx.restore();
}

function drawTrack() {  // disegna tutto ciò che c'è da vedere sul canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(center.carX, center.carY);
    ctx.rotate(-car.angle);
    ctx.translate(car.x, car.y);
    ctx.drawImage(trackImage, 0, 0, track.width, track.height); // disegna la pista in funzione della posizione della macchina
    if (gauntlet) drawGhost();   // disegna il fantasma solo se siamo in una sfida
    //drawBarriers();
    ctx.restore();
}

function checkCollision() {
    // funzione per il controllo delle collisioni
    // essengo questa funzione ripetuta molto spesso è essenziale che sia ottimizzata al meglio
    car.fr = [-car.x + (sideY2 * car.cosA - sideX2 * car.sinA), -car.y + (sideY2 * car.sinA + sideX2 * car.cosA)];  // gli angoli della macchina sono calcolati usando il seno ed il coseno corrente dell'angolo della macchina
    car.fl = [-car.x - (sideX1 * car.cosA - sideY1 * car.sinA), -car.y - (sideX1 * car.sinA + sideY1 * car.cosA)]; 
    car.br = [-car.x + (sideX1 * car.cosA - sideY1 * car.sinA), -car.y + (sideX1 * car.sinA + sideY1 * car.cosA)];
    car.bl = [-car.x - (sideY2 * car.cosA - sideX2 * car.sinA), -car.y - (sideY2 * car.sinA + sideX2 * car.cosA)];
    for (let i = 0; i < gameBarriers.length; i++) {
        if (!gameBarriers[i].visible) continue; // questo controllo ottimizza il costo del collision detection: non tutte le barriere sono sempre visibili
        if (cercaIntersezione(car.fr[0], car.fr[1], car.fl[0], car.fl[1], gameBarriers[i].x1, gameBarriers[i].y1, gameBarriers[i].x2, gameBarriers[i].y2)) return gameBarriers[i].id; // scontro frontale
        if (cercaIntersezione(car.bl[0], car.bl[1], car.br[0], car.br[1], gameBarriers[i].x1, gameBarriers[i].y1, gameBarriers[i].x2, gameBarriers[i].y2)) return gameBarriers[i].id; // scontro sul retro
        if (cercaIntersezione(car.fl[0], car.fl[1], car.bl[0], car.bl[1], gameBarriers[i].x1, gameBarriers[i].y1, gameBarriers[i].x2, gameBarriers[i].y2)) return gameBarriers[i].id; // scontro a sinistra
        if (cercaIntersezione(car.fr[0], car.fr[1], car.br[0], car.br[1], gameBarriers[i].x1, gameBarriers[i].y1, gameBarriers[i].x2, gameBarriers[i].y2)) return gameBarriers[i].id; // scontro a destra
    }
    return 'n'; // "n" viene interpretato per nessuno scontro
}

function cercaIntersezione(x1, y1, x2, y2, x3, y3, x4, y4) {    // controlla se due segmenti sottesi tra due coppie di punti ((x1, y1), (x2, y2)) ((x3, y3), (x4, y4)) si intersecano o meno
    const tol = 5;  // tolleranza utilizzata nel calcolo finale
    var z1 = (x1 - x2);
    var z2 = (x3 - x4);
    var z3 = (y1 - y2);
    var z4 = (y3 - y4);
    var dist = z1 * z4 - z3 * z2;
    if (dist == 0) {    // se sono paralleli non si incontrano mai
      return false;
    }
    var tempA = (x1 * y2 - y1 * x2);
    var tempB = (x3 * y4 - y3 * x4);
    var xCoor = (tempA * z2 - z1 * tempB) / dist;   // troviamo il punto (xCoor, yCoor) di intersezione tra le due rette che si sovrappongono ai segmenti
    var yCoor = (tempA * z4 - z3 * tempB) / dist;
    if (xCoor < Math.min(x1, x2) - tol || xCoor > Math.max(x1, x2) + tol || xCoor < Math.min(x3, x4) - tol || xCoor > Math.max(x3, x4) + tol) return false; // se l'intersezione non è contenuta tra i punti dei segmenti allora non è sul segmento
    if (yCoor < Math.min(y1, y2) - tol || yCoor > Math.max(y1, y2) + tol || yCoor < Math.min(y3, y4) - tol || yCoor > Math.max(y3, y4) + tol) return false;
    return true;    // il punto di intersezione è valido
}

function checkBoundaries() {    // si occupa di gestire il campo "visibile" di un oggetto barriera
        // si immagina un quadrato attorno all'auto di dimensione fissa. Ad intervalli di circa 6 volte al secondo si controllano tutte le barriere del gioco per capire quale sia visibile all'auto
        // essendo il controllo sulle collisioni eseguito molto più spesso di questa funzione, eseguirlo sulle sole barriere visibili selezionate da questa funzione riduce di molto il carico client
    square = [-car.x - barrierCheckR, -car.y + barrierCheckR, -car.x + barrierCheckR, -car.y - barrierCheckR]; // quadrato attorno alla macchina
    for (let i = 0; i < gameBarriers.length; i++) { // scorriamo il vettore delle barriere globali per aggiornare l'insieme delle barriere visibili
        // controlliamo prima se la barriera è contenuta: basta verificare che uno dei suoi punti si trovi nel quadrato che circonda la macchina
        if (((square[0] <= gameBarriers[i].x1) && (gameBarriers[i].x1 <= square[2]) && (square[3] <= gameBarriers[i].y1) && (gameBarriers[i].y1 <= square[1])) ||
            ((square[0] <= gameBarriers[i].x2) && (gameBarriers[i].x2 <= square[2]) && (square[3] <= gameBarriers[i].y2) && (gameBarriers[i].y2 <= square[1]))) {
            gameBarriers[i].visible = true;
            continue;
        }
        // invece per verificare se la barriera tocca il quadrato basta controllare se si interseca alle sue diagonali (tutti gli altri casi di intersezione sono coperti dal controllo precedente)
        if (cercaIntersezione(gameBarriers[i].x1, gameBarriers[i].y1, gameBarriers[i].x2, gameBarriers[i].y2, square[0], square[1], square[2], square[3]) ||
            cercaIntersezione(gameBarriers[i].x1, gameBarriers[i].y1, gameBarriers[i].x2, gameBarriers[i].y2, square[0], square[3], square[2], square[1])) {
            gameBarriers[i].visible = true;
            continue;
        }
        gameBarriers[i].visible = false; // se nessuno dei controlli precedenti ha aggiunto la barriera allora questa può lasciare le barriere visibili
    }
}

function formatTs(ts) {     // funzione di format dei timestamp
    const min = Math.floor(ts / 60000);
    const sec = Math.floor((ts % 60000) / 1000);
    const ms = ts % 1000;
    return String(min).padStart(2, '0') + ":" + String(sec).padStart(2, '0') + ":" + String(ms).padStart(3, '0');
}

function sleep(ms) {    // sleep() fai da te
    return new Promise(resolve => setTimeout(resolve, ms));
}

function returnFun() {  // uscita dal gioco
    window.location.href = "../homepage/homeIndex.php";
}

async function gameOver() {     // funzione di termine gioco. In timestamp[0] finisce il tempo impiegato
    let timeOver = Date.now();
    timestamp[0] = timeOver - timestamp[0];
    intervals[0].clear();   // termine della ripetizione di funzioni
    intervals[1].clear();
    intervals[2].clear();
    intervals[3].clear();
    await sendPos();    // inviamo i dati relativi alla partita appena svolta
}

function checkpointCrossed() {  // gestione della collisione con un checkpoint. Una mappa contiene 4 checkpoint, traguardo compreso, per evitare che un player possa percorrere all'indietro la pista
    if (collisionID != nextCheck) return;   // se non è il checkpoint che ci aspettiamo no nfare nulla
    if (collisionID == 'c0') {  // se attraversiamo il traguardo salva il tempo di attraversamento e stampalo
        timestamp[lapCount] = Date.now();
        lapDuration.innerText += lapCount + ":  " + formatTs(timestamp[lapCount] - timestamp[lapCount - 1]) + "\r";
        if (lapCount == 3) {    // se siamo al terzo giro allora la partita è finita
            lapDuration.innerText += "\nTotale: " + formatTs(timestamp[lapCount] - timestamp[0]);
            gameOver();
            return;
        }
        lapCount++; // se non si tratta del terzo giro incrementa l'iteratore di giro
        lapField.innerText = "Giro " + lapCount;
    }
    let n = parseInt(nextCheck[1]); // passa al prossimo checkpoint
    n = (n + 1) % 4;
    nextCheck = 'c' + n.toString();
}

function updatePosition() { // aggiorna la posizione dell'auto
    let dx = 0, dy = 0; // spostamenti
    let color = ctx.getImageData(center.carX, center.carY, 1, 1).data;  // leggi il colore del tracciato sotto il centro dell'auto
    grass = (color[1] < 200 && color[1] > 80 && color[0] < 100) ? 1 : 0;    // questa condizione isola le sole sfumature di colore relative al verde dell'erba
    let s = grass ? topSpeed / 8 : topSpeed;    // il booleano "grass" modifica il calcolo della velcoità dell'auto qualora questa fosse sull'erba per rallentarla
    let rs = grass ? reverseTopSpeed / 3 : reverseTopSpeed;
    if (car.speed > s) car.speed -= (0.1 + 0.2 * grass); // la macchina aveva superato la top speed a causa di un turbo, va fatta rallentare
    if (keys.ArrowUp) { // lettura dei tasti e gestione della velocità
        if (car.speed <= s) car.speed += 0.2;
    }
    if (keys.ArrowDown) {
        if (car.speed >= -rs) car.speed -= 0.1;
    }
    if (!keys.ArrowDown && !keys.ArrowUp) {   // la macchina di per sè rallenta se non è premuto alcun tasto
        if (car.speed < 0) car.speed += 0.05;
        if (car.speed > 0) car.speed -= 0.05;
        if (car.speed >= -0.05 && car.speed <= 0.05) car.speed = 0;
    }

    car.sinA = Math.sin(car.angle); // calcolo seno e coseno in relazione all'orientamento dell'auto
    car.cosA = Math.cos(car.angle);

    dx = car.speed * car.sinA;  // calcolo dello spostamento
    dy = -car.speed * car.cosA;

    car.x -= dx;    // aggiorna la posizione dell'auto
    car.y -= dy;

    collisionID = checkCollision(); // diamo per scontato che la macchina esegua lo spostamento richiesto: se però si rileva una collisione tale spostamento viene negato
    switch (collisionID[0]) {
        case 'n':   // se non si ha alcuna collisione non fare nulla
            break;
        case 'c':   // se si collide con un checkpoint allora gestiscilo
            checkpointCrossed();
            break;
        default:    // se si collide con qualcosa ripristina la posizione precedente con rimbalzo
            car.speed /= 4;
            car.x += (dx * 4);
            car.y += (dy * 4);
    }
}

function drift() {  // gestisce il drift dell'auto
    if (car.inBoost < 20) {    // se spazio è stato tenuto per troppo poco tempo non si fa il drift
        car.inBoost = 0;
        return;
    }
    if (car.inBoost > 100) car.inBoost = 100;   // se il drift è eccessivo limitalo
    car.speed = car.speed + car.inBoost * boostMultiplier;  // aumenta la velocità
    car.inBoost = 0;    // resetta il contatore del boost
    boostBar.style.height = "0%";   // modifica le dimensioni della barra del boost
}

function speedBoostBars() { // modifica le dimensioni della barra di velocità dell'auto
    speedBar.style.height = Math.abs(car.speed * 100 / (topSpeed + 7)) + "%"; //massima speed = top_speed + 7. %/80 = car/top
    boostBar.style.height = Math.min((car.inBoost - 20) * 1.25, 100) + "%";
}

function update() { // funzione di update generale dell'auto 
    let check = car.inBoost ? 1 : 0;    // controllo se la macchina è in boost o meno: se lo è le curve vengono prese più strette
    if (keys.ArrowLeft) {   // sterzate
        if (car.speed < -0.8) car.angle -= (0.1 * car.speed + check) * 0.0174; // pi/180 vale 0.0174532925199
        if (car.speed > 0.8) car.angle -= (0.15 * car.speed + check) * 0.0174; // alla macchina è consentito sterzare solo se possiede un minimo di velocità
    }
    if (keys.ArrowRight) {
        if (car.speed < -0.8) car.angle += (0.1 * car.speed + check) * 0.0174; 
        if (car.speed > 0.8) car.angle += (0.15 * car.speed + check) * 0.0174;
    }
    if (keys.Space && (keys.ArrowLeft || keys.ArrowRight)) {    // per compiere un drift è necessario premere lo spazio ed una delle due frecce laterali
        car.inBoost += 1;
    }
    if (!keys.Space && car.inBoost) drift();    // se spazio è rilasciato e la macchina è ancora in boost allora si sta tentando di boostare

    updatePosition();   // chiama le altre funzioni di update di gioco
    drawTrack();
    drawCar();
    speedBoostBars();
}

function engineVibrate() {  // modifica una variabile in modo che l'auto venga disegnata per "vibrare" come se fosse in moto
    carEngine = (carEngine + 1) % 2;
}

async function countdown() {    // funzione di inizio corsa: mette a video il countdown
    var target = document.getElementById("charScreen");
    var targetDiv = document.getElementById("overlay");
    target.innerText = "3";
    await sleep(1000);
    target.innerText = "2";
    await sleep(1000);
    target.innerText = "1";
    await sleep(1000);
    target.innerText = "GO!";
    target.className = "fade-out";
    targetDiv.className = "fade-out";
}

async function start() {    // funzione di inizio gioco: inizializza l'essenziale
    await dataInit();   // richiedi i dati di gioco
    trackImage.onload = async function () { // disegnamo tracciato e macchina una prima volta (per ora il gioco è in pausa)
        ctx.clearRect(0, 0, canvas.width, canvas.height);   // disegna la pista e l'auto una prima volta
        ctx.save();
        ctx.translate(center.carX, center.carY);
        ctx.rotate(-car.angle);
        ctx.translate(car.x, car.y);
        ctx.drawImage(trackImage, 0, 0, track.width, track.height);
        ctx.restore();
        drawCar();
    }
    await countdown();  // inizia il countdown e salva l'istante di partenza
    timestamp[0] = Date.now();
    storePos(); // salva una prima posizione
    // esegue l'inizializzazione degli intervalli per le funzioni periodiche
    intervals[0] = driftCorrectingInterval(update, 16); // circa 60 volte al secondo
    intervals[1] = driftCorrectingInterval(engineVibrate, 50);
    intervals[2] = driftCorrectingInterval(checkBoundaries, 1800/topSpeed); // circa 6 volte al secondo: 10 volte meno frequente grazie all'ottimizzazione delle barriere
    intervals[3] = driftCorrectingInterval(storePos, sampleTime);   // salvataggio dei campioni del proprio percorso
}

document.addEventListener('keydown', function (event) { // eventi relativi alla pressione dei tasti
    switch (event.key) {
        case 'w':
            keys.ArrowUp = true;
            break;
        case 's':
            keys.ArrowDown = true;
            break;
        case 'a':
            keys.ArrowLeft = true;
            break;
        case 'd':
            keys.ArrowRight = true;
            break;
        case ' ':
            keys.Space = true;
            break;
        case 'W':
            keys.ArrowUp = true;
            break;
        case 'S':
            keys.ArrowDown = true;
            break;
        case 'A':
            keys.ArrowLeft = true;
            break;
        case 'D':
            keys.ArrowRight = true;
            break;
        default:
            break;
    }
});

document.addEventListener('keyup', function (event) { // eventi relativi al rilascio dei tasti
    switch (event.key) {
        case 'w':
            keys.ArrowUp = false;
            break;
        case 's':
            keys.ArrowDown = false;
            break;
        case 'a':
            keys.ArrowLeft = false;
            break;
        case 'd':
            keys.ArrowRight = false;
            break;
        case ' ':
            keys.Space = false;
            break;
        case 'W':
            keys.ArrowUp = false;
            break;
        case 'S':
            keys.ArrowDown = false;
            break;
        case 'A':
            keys.ArrowLeft = false;
            break;
        case 'D':
            keys.ArrowRight = false;
            break;
        default:
            break;
    }
});

start();    // chiama il resto del codice