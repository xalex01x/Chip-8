<?php
require ('../other/db.php');
session_start();    // verifichiamo che una sessione sia già attiva
if (!isset($_SESSION["user"]) || !isset($_SESSION["currentTrack"])) {
    header("Location: ../index.html");
    exit;
}

header('Content-Type: application/json');   // la sintassi necessaria per la lettura dei dati json è stata presa da https://stackoverflow.com/questions/18866571/receive-json-post-with-php
$jsonData = file_get_contents('php://input');   // leggiamo lo stream di input per leggerne il contenuto: ci aspettiamo del codice json contenente il tragitto del player
$playerPos = json_decode($jsonData, true);
if (json_last_error() === JSON_ERROR_NONE) {    // se non vi sono stati errori con la lettura dei dati json allora puoi proseguire
    try {
        $validi = '/^[0-9]+$/';
        $db = new DB();
        $pdo = $db->retPDO();
        $user = $_SESSION["user"];
        $track = $_SESSION["currentTrack"];
        if (!preg_match($validi, $track)) {     // gestione degli errori: se qualcosa di erroneo avviene allora porta l'utente alla pagina di errore
            $_SESSION["errorLog"] = '';
            $_SESSION["error"] = "L'ID della pista selezionata non è un numero.";
            $db->endPDO();
            header("Location: ../other/errorPage.php");
            exit;
        }
        $tempo = $playerPos[0];
        if (!preg_match($validi, $tempo)) {
            $_SESSION["errorLog"] = '';
            $_SESSION["error"] = "Il tempo del percorso selezionato non è un numero.";
            $db->endPDO();
            header("Location: ../other/errorPage.php");
            exit;
        }
        $sql = "SELECT time FROM ghostData WHERE player = :player AND trackID = :trackID";  // ottieni, se esistono, i precedenti dati del giocatore
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':player', $user);
        $stmt->bindParam(':trackID', $track);
        $stmt->execute();
        $row = $stmt->fetch();
        if (!$row) {    // se non esistono dei dati già presenti, allora questa è la prima partita del giocatore: salva nuovi dati
            $sql = "INSERT INTO ghostData (player, trackID, time, route) VALUES (:player, :trackID, :time, :route)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':player', $user);
            $stmt->bindParam(':trackID', $track);
            $stmt->bindParam(':time', $tempo);
            $stmt->bindParam(':route', $jsonData);
            $stmt->execute();
        } else {
            if ($tempo < $row["time"]) {    // se invece esistono dei dati allora sovrascrivili con i nuovi qualora il nuovo tempo fosse migliore del precedente
                $sql = "UPDATE ghostData SET time = :time, route = :route WHERE player = :player AND trackID = :trackID";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':time', $tempo);
                $stmt->bindParam(':route', $jsonData);
                $stmt->bindParam(':player', $user);
                $stmt->bindParam(':trackID', $track);
                $stmt->execute();
            }
        }   // se esistono già dei dati ed il tempo non è migliore allora nessuna azione è richiesta
        $db->endPDO();
    } catch (PDOException $e) {     // gestione errori
        $_SESSION["errorLog"] = $e->getMessage();
        $_SESSION["error"] = "Il server non è riuscito a salvare i dati relativi alla partita.";
        $db->endPDO();
        header("Location: ../other/errorPage.php");
    }
} else {    // gestione di eventuali dati json non validi
    $_SESSION["errorLog"] = '';
    $_SESSION["error"] = "Ricevuti dati non validi.";
    header("Location: ../other/errorPage.php");
}
exit;
?>