<?php
session_start();
if (!isset($_SESSION["user"]) || !isset($_SESSION["currentTrack"])) {   // verifichiamo che il player sia loggato e abbia appena corso su una pista
    header("Location: ../index.html");
    exit;
}
$trackID = $_SESSION['currentTrack'];   // assembliamo la riposta
if ($_SESSION['gauntlet'] != '' && $_SESSION['gauntletData'] != '') {
    $jsonData = $_SESSION['gauntletData'];  // se viene richiesto uno sfidante e questo ha già corso allora invia i dati
} else {
    $jsonData = ''; // se non è richiesta una sfida o lo sfidante non ha mai corso invia una risposta vuota
}
$response = array(  // rispondi con l'identificatore del tracciato e con i dati dello sfidante
    "trackID" => $trackID,
    "jsonData" => $jsonData
);
echo json_encode($response);    // inviamo al client i dati
?>