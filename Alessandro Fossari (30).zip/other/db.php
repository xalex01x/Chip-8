<?php
require "dbParams.php";
class DB {  // classe che raggruppa alcune funzioni di PDO in modo da non doverle riscrivere
    public $pdo;

    function __construct()
    {
        try {
            $connString = "mysql:host=" . DBHOST . ";dbname=" . DBNAME . "";
            $this->pdo = new PDO($connString, DBUSER, DBPASS);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            $response = ['error' => $e->getMessage()];
            die(json_encode($response));
        }
    }
    function retPDO()
    {
        return $this->pdo;
    }
    function endPDO()
    {
        $this->pdo = null;
    }
}
?>