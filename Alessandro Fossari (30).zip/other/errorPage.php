<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>All-Day Drifting</title>
    <style>
        @font-face {
            font-family: "Racing";
            src: url("Race Sport.ttf");
        }

        body {
            font-family: "Racing";
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        #errorDiv {
            background-color: red;
            color: whitesmoke;
            border-radius: 8px;
            padding: 5%;
        }

        #debugDiv {
            color: #333;
            margin: 5%;
        }

        a {
            margin: 5%;
        }

        #error, #debug {
            font-size: large;
        }

        #user, #currentTrack, #gauntlet {
            font-size: medium;
        }

        main {
            width:60%;
            height: 80%;
        }
    </style>
</head>
<body> <!-- pagina di messa a video degli errori per l'utente -->
    <main>
        <div id="errorDiv">
            <?php
            session_start();
            if (isset($_SESSION['error']))
                echo "<p id = \"error\">ERRORE: " . $_SESSION['error'] . "</p>";
            if (isset($_SESSION['errorLog']))
                echo "<p id = \"errorLog\">" . $_SESSION['errorLog'] . "</p>";
            ?>
        </div>
        <div id="debugDiv">
            <p id = "debug">Informazioni di debug:</p>
            <?php
            if (isset($_SESSION['user']))
                echo "<p id = \"user\">Player: " . $_SESSION['user'] . "</p>";
            else
                echo "<p>Player: --</p>";
            if (isset($_SESSION['currentTrack']))
                echo "<p id = \"currentTrack\">Track: " . $_SESSION['currentTrack'] . "</p>";
            else
                echo "<p>Track: --</p>";
            if (isset($_SESSION['gauntlet']))
                echo "<p id = \"gauntlet\">Sfidante: " . $_SESSION['gauntlet'] . "</p>";
            else
                echo "<p>Sfidante: --</p>";
            ?>
        </div>
        <div>
            <a href="javascript:history.go(-1)"><< Pagina precedente</a>
        </div>
    </main>
</body>
</html>