<?php
// parametri per l'inizializzazione di PDO
define('DBHOST', 'localhost');
define('DBNAME', 'fossari_616157');
define('DBUSER', 'root');
define('DBPASS', '');
?>