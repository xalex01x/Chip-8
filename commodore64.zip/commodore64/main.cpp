#include <iostream>
#include <fstream>
#include <cstring>
#include "macros.h"
using namespace std;

processor cpu;
wires bus;
u8 ram[16 * 0x1000];  // RAM: 16 pagine da 0x1000 byte ciscuna
u8 rom[5 * 0x1000];   // ROM: 5 pagine da 0x1000 byte ciscuna

u8 opcode;
u16 remainingCycles = 0;
u16 clockNUmber = 0;

void printbyte(u8 arg){
    cout << hex << static_cast<u16>(arg);
}

void printbinary(u8 arg){
    int i = 0;
    while(1){
        cout << ((arg & 0x80) >> 7);
        i++;
        if(i == 8) return;
        arg <<= 1;
    }
}

void ROMRead(char * path, u16 start){
    ifstream infile(path, ios::in | ios::binary);
    if (!infile.is_open()) {
        cout << "Errore nell'apertura della ROM" << endl;
        return;
    }
    int i = 0;
    while (!infile.eof()){
        rom[start + i] = infile.get();
        i++;
    }
}

bool debug = false;      // per la funzione sottostante
u8 readAddr(u16 addr){
    if((addr < BASIC_ROM) || (addr >= 0xC000 && addr < CHAR_ROM)){
        if(debug)cout << "   RAM("<< hex << addr << ") ";
        return ram[addr];
    }
    if(addr >= KERNAL_ROM) {
        if(ram[0x0001] & HIRAM){
            if(debug)cout << " K_ROM("<< hex << addr << ") ";
            return rom[addr - 0xB000];
        }
        if(debug)cout << " K_RAM("<< hex << addr << ") ";
        return ram[addr];
    }
    if(addr >= CHAR_ROM) {
        if(ram[0x0001] & CHAREN){
            if(debug)cout << " C_ROM("<< hex << addr << ") ";
            return rom[(addr & 0x0fff) | 0x2000];
        }
        if(debug)cout << " C_RAM("<< hex << addr << ") ";
        return ram[addr];
    }
    if(ram[0x0001] & LORAM){
        if(debug)cout << " B_ROM("<< hex << addr << ") ";
        return rom[addr - 0xA000];
    }
    if(debug)cout << " B_RAM("<< hex << addr << ") ";
    return ram[addr];
}

void signalVIC(u16 addr){

}

void writeAddr(u16 addr, u8 value){     // evita che la pcu possa scrivere in 0x00 e 0x01
    ram[addr] = value;
    if((addr & 0xff) == 0xd000 && addr <= 0xd02e) signalVIC(addr);  // controlla se la scrittura è avvenuta nello spazio di I/O del VIC
}

u16 readWord(u16 addr){ // legge una word posta all'indirizzo [addr + 1, addr]
    return readAddr(addr) | (readAddr(addr + 1) << 8);
}

void ZNflags(u8 value){
    cpu.flag = (value) ? cpu.flag & ~ZERO : cpu.flag | ZERO;
    cpu.flag = (value & NEGATIVE) | (cpu.flag & ~NEGATIVE);
}

void popPC();
void pushPC();


bool addrOpcodeInfo = false;
u16 checkpoint[] = {0xfce2, 0xfd02, 0xfcef, 0xfda3, 0xff6e, 0xfcf5, 0xfd15};
char * checkStrings[] = {"Entry point", "Check ROM", "ROM stat code", "I/O init", "CIA timers", "RAM test", "Vector set"};
int checkIter = 0;
u8 fetch() {
    cpu.pc++;
    if(cpu.pc == checkpoint[checkIter]) {
        cout << "Raggiunto: " << checkStrings[checkIter] << endl;
        checkIter++;
        //if(checkIter == 6) addrOpcodeInfo = true;
    }
    return readAddr(cpu.pc);
}
/*
    L'emulatore crede di essere NTSC
    0xd11 contiene: 10011011
    0xd16 contiene: 00001000
*/

void push(u8 reg){
    ram[STACK + cpu.sp--] = reg;
}

u8 pop(){
    return ram[STACK + (++cpu.sp)];
}

void pushPC(){
    push((cpu.pc >> 8));
    push((cpu.pc & 0x00ff));
}

void popPC(){
    cpu.pc = pop() | (pop() << 8);
}

bool taken = false; // per non ciclare uslle interrupt      DA TOGLIERE PRIMA O POI

void interrupt(char type){
    pushPC();
    push(cpu.flag);
    if(type == 'n'){
        cpu.pc = ((readAddr(0xFFFB) << 8) | readAddr(0xFFFA)) - 1; // routine NMII
        cpu.flag |= INTERRUPT;
        bus.NMI = 1;
    }
    else cpu.pc = ((readAddr(0xFFFF) << 8) | readAddr(0xFFFE)) - 1;         // routine IRQ/BRK
    bus.IRQ = 1;
}

void returnInterrupt(){
    cpu.flag = pop();
    popPC();
}

int main(int argc, char * argv[]) {

    // INIZIALIZZAZIONE ROM
    char path [64];
    strcpy(path, "./basic.901226-01.bin");
    ROMRead(path, 0);
    strcpy(path, "./characters.901225-01.bin");
    ROMRead(path, 0x1000 * 2);
    strcpy(path, "./kernal.901227-03.bin");
    ROMRead(path, 0x1000 * 3);

    // INIZIALIZZAZIONE RAM
    ram[0x00] = 0x2F;
    ram[0x01] = 0x37;

    // INIZIALIZZAZIONE BUS
    bus.IRQ = 1;
    bus.NMI = 1;

    //INIZIALIZZAZIONE CPU
    cpu.flag = 0x00;
    cpu.pc = ((readAddr(0xFFFD) << 8) | readAddr(0xFFFC)) - 1;    //0xFFFC reset address

    bool fetchDebug = false;
     addrOpcodeInfo = false;

    while(1){
        // INVIO DI COMANDI AL VIC


        
        if(remainingCycles) {
            clockNUmber++;
            remainingCycles --;
            continue;
        }

        // CONTROLLO INTERRUPT
        if((!bus.IRQ && !(cpu.flag & INTERRUPT))) {
            cout << "Gestione interrupt IRQ" << endl;
            interrupt('i');
            taken = 1;
        }
        if(!bus.NMI) {
            interrupt('n');
            taken = 1;
        }

        // FETCH ED ESECUZIONE
        if(fetchDebug){
            cout << " A:";
        printbyte(cpu.A);
        cout << "\t X:";
        printbyte(cpu.X);
        cout << "\t Y:";
        printbyte(cpu.Y);
        cout << "\t F:";
        printbyte(cpu.flag);
        cout << "\t S:";
        printbyte(cpu.sp);
        }
        
        opcode = fetch();       // FETCH


        if(addrOpcodeInfo){
            cout <<"addr: " << hex << cpu.pc << " op: ";
            printbyte(opcode);
            cout << endl;
        }

        if(opcode == 0x01){ // ORA (nn, X)
            cpu.A |= readAddr(INDEXED_INDIRECT_ADDRESSING);
            ZNflags(cpu.A);
            remainingCycles += 6;
            continue;
        }
        if(opcode == 0x05){ // ORA nn
            cpu.A |= readAddr(ZERO_PAGE_ADDRESSING);
            ZNflags(cpu.A);
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0x09){ //ORA #nn
            cpu.A |= readAddr(++cpu.pc);
            ZNflags(cpu.A);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x0D){ // ORA nnnn
            cpu.A |= readAddr(ABSOLUTE_ADDRESSING);
            ZNflags(cpu.A);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x10){ // BPL
            if(cpu.flag & NEGATIVE){
                cpu.pc++;
                remainingCycles += 2;
            } else {
                u16 oldPc = cpu.pc;
                u16 offset = (readAddr(cpu.pc + 1) & NEGATIVE) ? 0xff00 | readAddr(cpu.pc + 1) : 0x0000 | readAddr(cpu.pc + 1);
                cpu.pc = oldPc + offset + 1;
                remainingCycles += 3;
                if(((cpu.pc + 1) & 0xff00) != (oldPc & 0xff00)) remainingCycles += 1;
            }
            continue;
        }
        if(opcode == 0x18){ // CLC
            cpu.flag &= ~CARRY;
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x20){ // JSR nnnn
            cpu.pc += 2;
            pushPC();
            cpu.pc = (readAddr(cpu.pc) << 8) | (readAddr(cpu.pc - 1) & 0x00ff) - 1;
            remainingCycles += 6;
            continue;
        }
        if(opcode == 0x29){ // AND #nn
            cpu.A &= readAddr(++cpu.pc);
            ZNflags(cpu.A);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x2D){ // AND nnnn
            cpu.A &= readAddr(ABSOLUTE_ADDRESSING);
            ZNflags(cpu.A);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x30){ // BMI
            if(cpu.flag & NEGATIVE){
                u16 oldPc = cpu.pc;
                u16 offset = (readAddr(cpu.pc + 1) & NEGATIVE) ? 0xff00 | readAddr(cpu.pc + 1) : 0x0000 | readAddr(cpu.pc + 1);
                cpu.pc = oldPc + offset + 1;
                remainingCycles += 3;
                if(((cpu.pc + 1) & 0xff00) != (oldPc & 0xff00)) remainingCycles += 1;
            } else {
                cpu.pc++;
                remainingCycles += 2;
            }
            continue;
        }
        if(opcode == 0x2A){ // ROL A
            u8 oldCarry = cpu.flag & CARRY;
            cpu.flag = (cpu.A & 0x80) ? cpu.flag | CARRY : cpu.flag & ~CARRY;
            cpu.A <<= 1;
            cpu.A |= oldCarry;
            ZNflags(cpu.A);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x40){ // RTI
            returnInterrupt();
            continue;
        }
        if(opcode == 0x48){ // PHA
            push(cpu.A);
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0x4C){ // JMP nnnn
            cpu.pc = (ABSOLUTE_ADDRESSING) - 1;
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0x60){ // RTS
            popPC();
            remainingCycles += 6;
            continue;
        }
        if(opcode == 0x68){ // PLA
            cpu.A = pop();
            ZNflags(cpu.A);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x69){ // ADC #nn , DA FARE LA DECIMAL MODE
            if(cpu.flag & DECIMAL){
                cout << "decimal"<<endl;
                return 0;
            } else {
                u16 res = cpu.A + readAddr(++cpu.pc) + (cpu.flag & CARRY);
                cpu.A = res;
                ZNflags(cpu.A);
                cpu.flag = (res >> 8) | (cpu.flag & ~CARRY);
                remainingCycles += 2;
            }
            continue;
        }
        if(opcode == 0x6C){ // JMP (nnnn)
            u16 addr = ABSOLUTE_ADDRESSING;
            if((addr & 0x00ff) == 0x00ff) {
                cpu.pc = (readAddr(addr) | (readAddr(addr & 0x00ff) << 8)) - 1;
            } else {
                cpu.pc = readWord(addr) - 1;
            }
            remainingCycles += 5;
            continue;
        }
        if(opcode == 0x78){ //SEI
            cpu.flag |= INTERRUPT;
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x84){ // STY nn
            writeAddr(ZERO_PAGE_ADDRESSING, cpu.Y);
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0x85){ // STA nn
            writeAddr(ZERO_PAGE_ADDRESSING, cpu.A);
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0x86){ // STX nn
            writeAddr(ZERO_PAGE_ADDRESSING, cpu.X);
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0x88){ // DEY
            cpu.Y--;
            ZNflags(cpu.Y);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x8A){ // TXA
            cpu.A = cpu.X;
            ZNflags(cpu.A);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x8C){ // STY nnnn
            writeAddr(ABSOLUTE_ADDRESSING, cpu.Y);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x8D){ // STA nnnn
            writeAddr(ABSOLUTE_ADDRESSING, cpu.A);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x8E){ // STX nnnn
            writeAddr(ABSOLUTE_ADDRESSING, cpu.X);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x90){ // BCC
            if(cpu.flag & CARRY){
                cpu.pc++;
                remainingCycles += 2;
            } else {
                u16 oldPc = cpu.pc;
                u16 offset = (readAddr(cpu.pc + 1) & NEGATIVE) ? 0xff00 | readAddr(cpu.pc + 1) : 0x0000 | readAddr(cpu.pc + 1);
                cpu.pc = oldPc + offset + 1;
                remainingCycles += 3;
                if(((cpu.pc + 1) & 0xff00) != (oldPc & 0xff00)) remainingCycles += 1;
            }
            continue;
        }
        if(opcode == 0x91){ // STA (nn), Y
            writeAddr(INDIRECT_INDEXED_ADDRESSING, cpu.A);
            remainingCycles += 6;
            continue;
        }
        if(opcode == 0x94){ // STY nn, X
            writeAddr(ZERO_PAGE_X_ADDRESSING, cpu.Y);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x95){ // STA nn, X
            writeAddr(ZERO_PAGE_X_ADDRESSING, cpu.A);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x98){ // TYA
            cpu.A = cpu.Y;
            ZNflags(cpu.A);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x99){ // STA nnnn, Y
            writeAddr(ABSOLUTE_Y_ADDRESSING, cpu.A);
            remainingCycles += 5;
            continue;
        }
        if(opcode == 0x9A){ // TXS
            cpu.sp = cpu.X;
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x9D){ // STA nnnn, X
            writeAddr(ABSOLUTE_X_ADDRESSING, cpu.A);
            remainingCycles += 5;
            continue;
        }
        if(opcode == 0xA0){ // LDY #nn
            cpu.Y = readAddr(++cpu.pc);
            ZNflags(cpu.Y);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xA2){ // LDX #nn
            cpu.X = readAddr(++cpu.pc);
            ZNflags(cpu.X);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xA4){ // LDY nn
            cpu.Y = readAddr(ZERO_PAGE_ADDRESSING);
            ZNflags(cpu.Y);
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0xA5){ // LDA nn
            cpu.A = readAddr(ZERO_PAGE_ADDRESSING);
            ZNflags(cpu.A);
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0xA6){ // LDX nn
            cpu.X = readAddr(ZERO_PAGE_ADDRESSING);
            ZNflags(cpu.X);
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0xA8){ // TAY
            cpu.Y = cpu.A;
            ZNflags(cpu.Y);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xA9){ // LDA #nn
            cpu.A = readAddr(++cpu.pc);
            ZNflags(cpu.A);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xAA){ // TAX
            cpu.X = cpu.A;
            ZNflags(cpu.X);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xAC){ // LDY nnnn
            cpu.Y = readAddr(ABSOLUTE_ADDRESSING);
            ZNflags(cpu.Y);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0xAD){ // LDA nnnn
            cpu.A = readAddr(ABSOLUTE_ADDRESSING);
            ZNflags(cpu.A);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0xB0){ // BCS
            if(cpu.flag & CARRY){
                u16 oldPc = cpu.pc;
                u16 offset = (readAddr(cpu.pc + 1) & NEGATIVE) ? 0xff00 | readAddr(cpu.pc + 1) : 0x0000 | readAddr(cpu.pc + 1);
                cpu.pc = oldPc + offset + 1;
                remainingCycles += 3;
                if(((cpu.pc + 1) & 0xff00) != (oldPc & 0xff00)) remainingCycles += 1;
            } else {
                cpu.pc++;
                remainingCycles += 2;
            }
            continue;
        }
        if(opcode == 0xB1){ // LDA (nn), Y
            u16 addr = INDIRECT_INDEXED_ADDRESSING;
            cpu.A = readAddr(addr);
            ZNflags(cpu.A);
            remainingCycles += 5;
            if ((addr & 0xff00) != ((addr - cpu.Y) & 0xff00)) remainingCycles += 1;
            continue;
        }
        if(opcode == 0xB4){ // LDY nn, X
            cpu.Y = readAddr(ZERO_PAGE_X_ADDRESSING);
            ZNflags(cpu.Y);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0xB5){ // LDA nn, X
            cpu.A = readAddr(ZERO_PAGE_X_ADDRESSING);
            ZNflags(cpu.A);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0xB9){ // LDA nnnn, Y
            u16 addr = ABSOLUTE_Y_ADDRESSING;
            cpu.A = readAddr(addr);
            ZNflags(cpu.A);
            remainingCycles += 4;
            if ((addr & 0xff00) != ((addr - cpu.Y) & 0xff00)) remainingCycles += 1;
            continue;
        }
        if(opcode == 0xBA){ // TSX
            cpu.X = cpu.sp;
            ZNflags(cpu.X);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xBD){ // LDA nnnn, X
            u16 base = readWord(cpu.pc + 1);
            u16 addr = ABSOLUTE_X_ADDRESSING;
            cpu.A = readAddr(addr);
            ZNflags(cpu.A);
            remainingCycles += 4;
            if ((addr & 0xff00) != (base & 0xff00)) remainingCycles += 1;
            continue;
        }
        if(opcode == 0xC8){ // INY
            cpu.Y++;
            ZNflags(cpu.Y);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xCA){ // DEX
            cpu.X--;
            ZNflags(cpu.X);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xD0){ // BNE
            if(cpu.flag & ZERO){
                cpu.pc++;
                remainingCycles += 2;
            } else {
                u16 oldPc = cpu.pc;
                u16 offset = (readAddr(cpu.pc + 1) & NEGATIVE) ? 0xff00 | readAddr(cpu.pc + 1) : 0x0000 | readAddr(cpu.pc + 1);
                cpu.pc = oldPc + offset + 1;
                remainingCycles += 3;
                if(((cpu.pc + 1) & 0xff00) != (oldPc & 0xff00)) remainingCycles += 1;
            }
            continue;
        }
        if(opcode == 0xD1){ // CMP (nn), Y
            u16 addr = INDIRECT_INDEXED_ADDRESSING;
            u8 res = cpu.A - readAddr(addr);
            ZNflags(res);
            cpu.flag = cpu.A >= readAddr(addr) ? cpu.flag & ~CARRY : cpu.flag | CARRY;
            remainingCycles += 5;
            if ((addr & 0xff00) != ((addr - cpu.Y) & 0xff00)) remainingCycles += 1;
            continue;
        }
        if(opcode == 0xD8){ // CLD
            cpu.flag &= (~DECIMAL);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xDD){ // CMP nnnn, X
            u16 base = readWord(cpu.pc + 1);
            u16 addr = ABSOLUTE_X_ADDRESSING;
            u8 res = cpu.A - readAddr(addr);
            ZNflags(res);
            cpu.flag = cpu.A >= readAddr(addr - cpu.X) ? cpu.flag & ~CARRY : cpu.flag | CARRY;
            remainingCycles += 4;
            if ((addr & 0xff00) != (base & 0xff00)) remainingCycles += 1;
            continue;
        }
        if(opcode == 0xE0){ // CPX #nn
            u8 res = cpu.X - readAddr(++cpu.pc);
            ZNflags(res);
            cpu.flag = cpu.X >= readAddr(cpu.pc) ? cpu.flag & ~CARRY : cpu.flag | CARRY;
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xE6){ // INC nn
            u16 addr = ZERO_PAGE_ADDRESSING;
            u8 value = ram[addr];
            writeAddr(addr, value + 1);
            ZNflags(ram[addr]);
            remainingCycles += 5;
            continue;
        }
        if(opcode == 0xE8){ // INX
            cpu.X++;
            ZNflags(cpu.X);
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0xF0){ // BEQ
            if(cpu.flag & ZERO){
                u16 oldPc = cpu.pc;
                u16 offset = (readAddr(cpu.pc + 1) & NEGATIVE) ? 0xff00 | readAddr(cpu.pc + 1) : 0x0000 | readAddr(cpu.pc + 1);
                cpu.pc = oldPc + offset + 1;
                remainingCycles += 3;
                if(((cpu.pc + 1) & 0xff00) != (oldPc & 0xff00)) remainingCycles += 1;
            } else {
                cpu.pc++;
                remainingCycles += 2;
            }
            continue;
        }

        cout << endl <<"indirizzo " << hex << cpu.pc << ": opcode non riconosciuto: ";
        printbyte(opcode);
        cout << endl;
        break;
    }
    return 0;
}

/*
        if(opcode == 0x0E){ // ASL nnnn
            u16 addr = ABSOLUTE_ADDRESSING;
            u8 value = readAddr(addr);
            cpu.flag = (value >> 7) ? cpu.flag | CARRY : cpu.flag & ~CARRY;
            value <<= 1;
            ZNflags(value);
            writeAddr(addr, value);
            continue;
        }
        if(opcode == 0x28){ // PLP
            cpu.flag = pop();
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0x38){ // SEC
            cpu.flag |= CARRY;
            remainingCycles += 2;
            continue;
        }
        if(opcode == 0x58){ // CLI
            cpu.flag &= ~INTERRUPT;
            remainingCycles += 2;
            continue;
        }
        
        if(opcode == 0x81){ // STA (nn, X)
            writeAddr(INDEXED_INDIRECT_ADDRESSING, cpu.A);
            remainingCycles += 6;
            continue;
        }
        if(opcode == 0x85){ // STA nn
            writeAddr(ZERO_PAGE_ADDRESSING, cpu.A);
            remainingCycles += 3;
            continue;
        }
        
        if(opcode == 0x8D){ // STA nnnn
            writeAddr(ABSOLUTE_ADDRESSING, cpu.A);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0xAE){ // LDX nnnn
            cpu.X = readAddr(ABSOLUTE_ADDRESSING);
            cpu.flag = (cpu.X) ? cpu.flag & ~ZERO : cpu.flag | ZERO;
            cpu.flag = (cpu.X & NEGATIVE) | (cpu.flag & ~NEGATIVE);
            remainingCycles += 4;
            continue;
        }
        if(opcode == 0xC4){ //CPY nn
            u8 res = cpu.Y - readAddr(ZERO_PAGE_ADDRESSING);
            ZNflags(res);
            cpu.flag = cpu.Y >= readAddr(readAddr(cpu.pc)) ? cpu.flag & ~CARRY : cpu.flag | CARRY;
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0xC5){ // CMP nn
            u8 res = cpu.A - readAddr(ZERO_PAGE_ADDRESSING);
            ZNflags(res);
            cpu.flag = cpu.A >= readAddr(readAddr(cpu.pc)) ? cpu.flag & ~CARRY : cpu.flag | CARRY;
            remainingCycles += 3;
            continue;
        }
        if(opcode == 0xCD){ // CMP nnnn
            u16 base = ABSOLUTE_ADDRESSING;
            u8 res = cpu.A - readAddr(base);
            ZNflags(res);
            cpu.flag = cpu.A >= readAddr(base) ? cpu.flag & ~CARRY : cpu.flag | CARRY;
            remainingCycles += 4;
            continue;
        }
        */

/*
Memory Map:
  0000-03FF OS RAM
  0400-07FF Screen Memory (40x25)
  0800-9FFF RAM
  A000-BFFF RAM/BASIC
  C000-CFFF RAM
  D000-DFFF RAM/CHARSET/IO
  E000-FFFF RAM/KERNAL
https://www.c64-wiki.com/wiki/Memory_Map
https://www.c64-wiki.com/wiki/Keyboard


DOC: https://c64os.com/post/6502instructions

ROM DISASSEMBLY https://www.pagetable.com/c64ref/c64disasm/#F5DD
MEMORY MAP https://www.pagetable.com/c64ref/c64mem/ 

VIC: https://www.cebix.net/VIC-Article.txt
*/
