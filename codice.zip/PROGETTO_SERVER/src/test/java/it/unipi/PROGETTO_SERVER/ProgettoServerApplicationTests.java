package it.unipi.PROGETTO_SERVER;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgettoServerApplicationTests {
}
