package it.unipi.PROGETTO_SERVER.Repositories;

import it.unipi.PROGETTO_SERVER.TabelleDB.Veicolo;
import org.springframework.data.repository.CrudRepository;

public interface VeicoloRepository extends CrudRepository<Veicolo, String> {
}
