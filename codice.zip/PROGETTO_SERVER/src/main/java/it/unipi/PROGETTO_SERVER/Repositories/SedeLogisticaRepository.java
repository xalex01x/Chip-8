package it.unipi.PROGETTO_SERVER.Repositories;

import it.unipi.PROGETTO_SERVER.TabelleDB.SedeLogistica;
import org.springframework.data.repository.CrudRepository;

public interface SedeLogisticaRepository extends CrudRepository<SedeLogistica, String> {
}
